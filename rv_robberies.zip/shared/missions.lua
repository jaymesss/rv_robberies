TradeMissions = {
    {
        Peds = {
            {
                Coords = vector4(1305.8, 4323.49, 38.23, 305.82),
                Model = 'a_m_m_afriamer_01',
                Weapon = 'WEAPON_COMBATPISTOL',
                Health = 2000,
                Main = true,
            },
            {
                Coords = vector4(1313.42, 4323.5, 38.15, 306.5),
                Model = 'a_m_m_beach_01',
                Weapon = 'WEAPON_ASSAULTRIFLE',
                Health = 2000,
                Main = false,
            },
            {
                Coords = vector4(1304.15, 4339.57, 41.32, 282.25),
                Model = 'a_m_m_rurmeth_01',
                Weapon = 'WEAPON_ASSAULTRIFLE',
                Health = 2000,
                Main = false,
            },
            {
                Coords = vector4(1306.13, 4345.81, 41.32, 256.89),
                Model = 'a_m_m_salton_03',
                Weapon = 'WEAPON_COMBATPISTOL',
                Health = 2000,
                Main = false,
            },
            {
                Coords = vector4(1321.85, 4353.66, 41.04, 242.87),
                Model = 'a_m_m_afriamer_01',
                Weapon = 'WEAPON_COMBATPISTOL',
                Health = 2000,
                Main = true,
            },
            {
                Coords = vector4(1337.99, 4325.23, 38.0, 354.26),
                Model = 'a_m_m_beach_01',
                Weapon = 'WEAPON_ASSAULTRIFLE',
                Health = 2000,
                Main = false,
            },
            {
                Coords = vector4(1339.15, 4338.5, 37.75, 241.84),
                Model = 'a_m_m_rurmeth_01',
                Weapon = 'WEAPON_ASSAULTRIFLE',
                Health = 2000,
                Main = false,
            },
        }
    },
}